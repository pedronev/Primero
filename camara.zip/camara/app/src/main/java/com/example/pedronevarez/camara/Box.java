package com.example.pedronevarez.camara;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;

/**
 * Created by pedro.nevarez on 26/02/2018.
 */

public class Box extends View {
    private Paint paint = new Paint();
    private static final String TAG = "Box";
    private float width, height;

    public Box(Context context, DisplayMetrics displayMetrics) {
        super(context);
        this.width = displayMetrics.widthPixels;
        this.height = displayMetrics.heightPixels;
    }

    /**
     * this makes the specific characteristics and style of the box.
     * @param canvas
     */
    @Override
    protected void onDraw(Canvas canvas) { // Override the onDraw() Method
        float realProportion = 1.48f;
        float offset = 50;
        float divisor = 2.4f; //Only change divisor to modify rect size
        super.onDraw(canvas);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.CYAN);
        paint.setStrokeWidth(10);

        Log.d(TAG, "Canvas width: " + width + ", Canvas height: " + height);
        //center
        float x0 = width/2;
        float y0 = height/2 - offset;
        float dx = (width/divisor);
        float dy = (dx * realProportion);
        //draw guide box
        canvas.drawRect(x0-dx, y0-dy, x0+dx, y0+dy, paint);
    }
}
