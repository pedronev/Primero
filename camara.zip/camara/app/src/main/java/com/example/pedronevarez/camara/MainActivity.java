package com.example.pedronevarez.camara;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

public class MainActivity extends Activity  {


    public static final int MEDIA_TYPE_IMAGE = 1;
    private static final String TAG = MainActivity.class.getName();
    static Camera mCamera;
    static FrameLayout preview;
    private static CameraPreview mPreview;
    final int PICK_FROM_CAMERA = 1;
    Bitmap bitmap;
    String fileName;
    private Handler mAutoFocusHandler;
    private boolean mPreviewing = true;

    private static final String name = "Camera";
    private static float ratioFinal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mCamera = getCameraInstance();

        mPreview = new CameraPreview(this, mCamera);
        preview = (FrameLayout) findViewById(R.id.camera_image);
        preview.addView(mPreview);

        Box box = new Box(this, getScreenSize(this));
        addContentView(box, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT));
        Log.d(TAG, "Picture size: " + mCamera.getParameters().getPictureSize().width + "x" + mCamera.getParameters().getPictureSize().height);
        Log.d(TAG, "Preview size: " + mCamera.getParameters().getPreviewSize().width + "x" + mCamera.getParameters().getPreviewSize().height);


        mAutoFocusHandler = new Handler();

        final Handler handler = new Handler();
        handler.postDelayed(doAutoFocus, 200);
    }



    private Runnable doAutoFocus = new Runnable() {
        public void run() {
            if (mCamera != null && mPreviewing) {
                safeAutoFocus();
            }
        }
    };
    Camera.AutoFocusCallback autoFocusCB = new Camera.AutoFocusCallback() {
        public void onAutoFocus(boolean success, Camera camera) {
            System.out.println("autofocus");

            mAutoFocusHandler.postDelayed(doAutoFocus, 3000);

        }
    };
    private Camera.PictureCallback mPicture = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {

            fileName = "tempIMG.jpg";

            try {
                FileOutputStream fileOutStream = openFileOutput(fileName, MODE_WORLD_READABLE);
                fileOutStream.write(data);
                fileOutStream.close();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }

            //	File filePath = getFileStreamPath(fileName);

            //	BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            //	Bitmap bitmap = BitmapFactory.decodeFile(filePath.getAbsolutePath(), bmOptions);

            //Intent i = new Intent(getApplicationContext(), DisplayImage.class);

            System.out.println("Past activity " + fileName);
            Bundle bundle = new Bundle();
            // bundle.putString("index",fileName);
            //i.putExtra("photoPath", fileName);
            //startActivityForResult(i, PICK_FROM_CAMERA);

        }

    };

    /**
     * this method opens the camera and prepares it to take a picture.
     * @return null if camera is unavailable.
     */
    public Camera getCameraInstance() {

        Camera c = null;
        try {
            c = Camera.open(); // attempt to get a Camera instance
            // set camera to continually auto-focus
            Camera.Parameters params = c.getParameters();
            // params.setRotation(90);
            //List<Size> pictureSizes = new ArrayList<Size>();

            //get the support size picture
            //pictureSizes = params.getSupportedPictureSizes();

            params.setWhiteBalance(Camera.Parameters.WHITE_BALANCE_AUTO);


            // Set the flash mode to auto.
            //  params.setFlashMode(Camera.Parameters.FLASH_MODE_AUTO);

            // Set the scene mode to auto.
            params.setSceneMode(Camera.Parameters.SCENE_MODE_AUTO);

            //Select picture size 1600*1200
            //params.setPictureSize(1600, 1200);

            //Estimate screen ratio
            ratioFinal = getScreenRatio();
            //Set picture size
            Camera.Size pictureSize = selectBestSize(c.getParameters().getSupportedPictureSizes(), ratioFinal, 0.2f); //Select picture size using a ratio 4:3
            params.setPictureSize(pictureSize.width, pictureSize.height);

            //Set preview sizes//
            Camera.Size previewSizes =  selectBestSize(params.getSupportedPreviewSizes(), ratioFinal, 0.124f);
            params.setPreviewSize(previewSizes.width, previewSizes.height);
            //Log.d(TAG, "Preview size1: " + params.getPreviewSize().width + "x" + params.getPreviewSize().height);

            //Focal Length value
            float focalLength = params.getFocalLength();
            Log.d(TAG, "Focal Length: " + focalLength);
            //Sensor height
            float verticalViewAngle = params.getVerticalViewAngle();
            float horizontalViewAngle = params.getHorizontalViewAngle();
            double sensorHeight = Math.tan(Math.toRadians(verticalViewAngle/2))*2*focalLength;
            double sensorWidth = Math.tan(Math.toRadians(horizontalViewAngle/2))*2*focalLength;
            Log.d(TAG, "Sensor height: " + sensorHeight);
            Log.d(TAG, "Sensor width: " + sensorWidth);


            params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);

            List<String> focusModes = params.getSupportedFocusModes();
            Log.d(TAG, "focusModes= " + focusModes);
            if (focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                Log.d(TAG, "focusModes= Continuous");
                params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            } else if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                Log.d(TAG, "focusModes= auto");
                params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            }
            //Log.d(TAG, params.flatten());
            c.setParameters(params);
        } catch (Exception e) {
            // Camera is not available (in use or does not exist)

            System.out.println("this is the error on open camera" + e);
        }
        return c; // returns null if camera is unavailable
    }

    private static Uri getOutputMediaFileUri(int type) {
        return Uri.fromFile(getOutputMediaFile(type));
    }

    // Create a File for saving an image or video
    private static File getOutputMediaFile(int type) {

        System.out.println("crea el archivo ");
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.

        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "MyCameraApp");
        // This location works best if you want the created images to be
        // shared
        // between applications and persist after your app has been
        // uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("MyCameraApp", "failed to create directory");
                return null;
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".jpg");
        } else {
            return null;
        }

        return mediaFile;
    }




    @Override
    protected void onStart() {
        super.onStart();
        System.out.println("entra OnStart camera activity");
        // Create our Preview view and set it as the content of our activity.
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseCamera();
        System.out.println("entra OnPause camera activity");
        mPreviewing = false;

    }

    // On Stop disconnect the GoogleClient object
    @Override
    protected void onStop() {
        System.out.println("entra OnStop camera activity");
        releaseCamera(); // release the camera immediately on pause event
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();


        if (mCamera == null) {
            mCamera = getCameraInstance();
            preview.removeAllViews();
            mPreview = new CameraPreview(this, mCamera);
            preview = (FrameLayout) findViewById(R.id.camera_image);
            preview.addView(mPreview);
            mPreviewing = true;
        }
        final Handler handler = new Handler();
        handler.postDelayed(doAutoFocus, 200);
        System.out.println("entra OnResume camera activity");

    }

    /**
     * This is a try catch method to made a safe auto focus
     */
    public void safeAutoFocus() {
        try {
            mCamera.autoFocus(autoFocusCB);
        } catch (RuntimeException e) {
            // Horrible hack to deal with autofocus errors on Sony devices
            // See https://github.com/dm77/barcodescanner/issues/7 for example
            scheduleAutoFocus(); // wait 1 sec and then do check again
        }
    }

    private void scheduleAutoFocus() {
        mAutoFocusHandler.postDelayed(doAutoFocus, 1000);
    }

    @Override
    protected void onDestroy() {
        System.out.println("entra OnDestroy camera activity ");
        super.onDestroy();
    }

    private void releaseCamera() {
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.setPreviewCallback(null);
            mPreview.getHolder().removeCallback(mPreview);
            mCamera.release();        // release the camera for other applications
            mCamera = null;
        }
    }

    private boolean checkCameraHardware(Context context) {
        if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            // this device has a camera
            return true;
        } else {
            // no camera on this device
            return false;
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {

            switch (requestCode) {

                case PICK_FROM_CAMERA:

                    Intent intent = new Intent();
                    System.out.println("this is filename" + fileName);
                    intent.putExtra("photoPath", fileName);
                    setResult(RESULT_OK, intent);
                    finish();

                    break;
            }
        }

    }

    /**
     * this method takes the picture.
     * @param v
     */
    public void takePicture(View v) {


        try {
            //System.gc();
            mCamera.takePicture(null, null, mPicture);


        } catch (Exception e) {

            System.out.println("this is the error on mCamera" + e);
        }
    }

    //Select picture size for a desired ratio
    protected static Camera.Size selectBestSize(List<Camera.Size> sizes, float ratio, float th){
        Camera.Size s;

        Collections.sort(sizes, new Comparator<Camera.Size>() { //Sort high to low
            @Override
            public int compare(Camera.Size lhs, Camera.Size rhs) {
                return Double.compare(rhs.width, lhs.width);
            }
        });

        for (Camera.Size z: sizes){
            float calcRatio = (float)z.width/z.height;
            Log.d(TAG, "Picture sizes: " + z.width + "x" + z.height + ", ratio: " + calcRatio +
                    ", thUp: " + (calcRatio + th) + ", thDwn: " + (calcRatio - th));
            if (ratio > (calcRatio - th) && ratio <(calcRatio + th)){
                Log.d(TAG, "Ratio Inside boundaries, " + z.width + "x" + z.height);
                return z;
            }
        }
        //If no ratio found return higher size
        Log.d(TAG, "Ratio NOT Inside boundaries");
        return sizes.get(0);

    }

    /**
     * this method gets the display metrics.
     * @param activity
     * @return
     */
    public static DisplayMetrics getScreenSize(Activity activity){
        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics;
    }

    /**
     * this method gets the device screen ratio.
     * @return the ratio.
     */
    protected float getScreenRatio(){
        DisplayMetrics displayMetrics = getScreenSize(this);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        float ratio = (float)height/width;
        Log.d(TAG,"Screen ratio: " + ratio);
        return ratio;
    }

}


